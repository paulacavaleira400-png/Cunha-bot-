# 𝓒𝓾𝓷𝓱𝓪 𝓫𝓸𝓽 — protótipo inicial

## O que este projeto faz
- Recebe comandos em uma página de teste.
- Restringe comandos a números cadastrados como ADM.
- Registra um link do TikTok por pessoa (`/tiktok @pessoa link`).
- Simula castigos leves (`/castigo`, `/perdoar`, `/castigos`, `/meucastigo`).
- Responde a `/pesquisa`, `/play`, `/audio` e `/sticker` com avisos de que essas integrações ainda não existem.

## O que NÃO faz
Este protótipo não entra em grupos, não lê mensagens do WhatsApp, não baixa vídeos do TikTok e não envia mídia pelo WhatsApp. O link salvo não é um arquivo de vídeo. A integração real depende de uma API/provedor compatível e das permissões/regras aplicáveis ao grupo.

## Executar em um servidor Node.js
1. Instale Node.js 18 ou superior.
2. Execute `npm install`.
3. Configure a variável de ambiente `ADMIN_NUMBERS` com números de teste separados por vírgula, em formato internacional sem `+`.
4. Execute `npm start`.
5. Abra o endereço do servidor no navegador.

## Segurança
- Não compartilhe QR Code de pareamento, código SMS/WhatsApp, senha ou token com terceiros.
- Não use seu número principal em bibliotecas não oficiais.
- Use apenas vídeos que você tem autorização para compartilhar.
- Os dados deste protótipo ficam em memória e somem quando o servidor reinicia.
