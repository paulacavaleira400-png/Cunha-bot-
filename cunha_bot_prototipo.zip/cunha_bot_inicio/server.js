import express from "express";

const app = express();
app.use(express.json());
app.use(express.static("public"));

const PORT = process.env.PORT || 3000;

// Configure os números dos administradores no ambiente do servidor,
// no formato internacional, separados por vírgula. Ex.: 5521999999999
const ADMINS = new Set(
  (process.env.ADMIN_NUMBERS || "")
    .split(",")
    .map((n) => n.replace(/\D/g, ""))
    .filter(Boolean)
);

// Dados em memória: serão apagados quando o servidor reiniciar.
// Para uma versão definitiva, use um banco de dados.
const tiktokByPerson = new Map();
const punishments = new Map();

const jokes = [
  "🐸 Você virou o SAPINHO OFICIAL do grupo!",
  "🤡 Você ganhou o título de PALHAÇO DO DIA!",
  "🐢 Você foi promovido(a) a TARTARUGA DO GRUPO!",
  "👑 Você é a pessoa mais dramática do grupo por 10 minutos!",
  "🦆 Quack! Você é o PATO HONORÁRIO do grupo!"
];

function normalizePerson(value = "") {
  return value.trim().replace(/^@/, "").toLowerCase();
}

function parseCommand(text = "") {
  const trimmed = text.trim();
  const firstSpace = trimmed.indexOf(" ");
  const command = (firstSpace === -1 ? trimmed : trimmed.slice(0, firstSpace))
    .toLowerCase();
  const args = firstSpace === -1 ? "" : trimmed.slice(firstSpace + 1).trim();
  return { command, args };
}

// Endpoint de teste: simula uma mensagem recebida.
// Não está conectado ao WhatsApp.
app.post("/api/message", (req, res) => {
  const { sender, text, mentions = [] } = req.body || {};
  const senderNumber = String(sender || "").replace(/\D/g, "");
  const message = String(text || "");
  const { command, args } = parseCommand(message);

  if (!senderNumber || !message) {
    return res.status(400).json({ reply: "Informe sender e text." });
  }

  // Todos os comandos são exclusivos dos administradores.
  if (command.startsWith("/") && !ADMINS.has(senderNumber)) {
    return res.json({
      reply: "🚫 Acesso negado! Somente ADM pode usar o Cunha bot."
    });
  }

  if (command === "/menu" || command === "/menuadm") {
    return res.json({
      reply: [
        "🤖 𝓒𝓾𝓷𝓱𝓪 𝓫𝓸𝓽",
        "/tiktok @pessoa link",
        "/tiktok lista",
        "/tiktok remover @pessoa",
        "/castigo @pessoa",
        "/perdoar @pessoa",
        "/castigos",
        "/meucastigo",
        "/pesquisa assunto",
        "/play música",
        "/sticker"
      ].join("\n")
    });
  }

  if (command === "/tiktok") {
    if (args.toLowerCase() === "lista") {
      const list = [...tiktokByPerson.keys()];
      return res.json({
        reply: list.length
          ? "🎬 Vídeos cadastrados: " + list.map((p) => "@" + p).join(", ")
          : "Ainda não há vídeos cadastrados."
      });
    }

    if (args.toLowerCase().startsWith("remover ")) {
      const person = normalizePerson(args.slice(8).split(/\s+/)[0]);
      tiktokByPerson.delete(person);
      return res.json({ reply: `🗑️ Cadastro de @${person} removido.` });
    }

    const match = args.match(/^@?([^\s]+)\s+(https?:\/\/\S+)$/i);
    if (!match) {
      return res.json({
        reply: "Use: /tiktok @pessoa https://link-do-video"
      });
    }

    const person = normalizePerson(match[1]);
    const url = match[2];
    if (!["http:", "https:"].includes(new URL(url).protocol)) {
      return res.json({ reply: "Envie um link válido." });
    }
    tiktokByPerson.set(person, url);
    return res.json({
      reply: `✅ Link cadastrado para @${person}. Para enviar o vídeo como mídia, a integração precisa receber um arquivo de vídeo autorizado; guardar o link não envia o arquivo.`
    });
  }

  if (command === "/castigo") {
    const person = normalizePerson(args.split(/\s+/)[0]);
    if (!person) return res.json({ reply: "Use: /castigo @pessoa" });
    const joke = jokes[Math.floor(Math.random() * jokes.length)];
    punishments.set(person, { joke, until: Date.now() + 10 * 60 * 1000 });
    return res.json({ reply: `🎭 Castigo de brincadeira para @${person}:\n${joke}\n⏳ Duração: 10 minutos.` });
  }

  if (command === "/perdoar") {
    const person = normalizePerson(args.split(/\s+/)[0]);
    if (!person) return res.json({ reply: "Use: /perdoar @pessoa" });
    punishments.delete(person);
    return res.json({ reply: `💚 @${person} foi perdoado(a)!` });
  }

  if (command === "/castigos") {
    for (const [person, data] of punishments) {
      if (data.until <= Date.now()) punishments.delete(person);
    }
    const active = [...punishments.entries()];
    return res.json({
      reply: active.length
        ? active.map(([p, d]) => `@${p}: ${d.joke}`).join("\n")
        : "Nenhum castigo ativo."
    });
  }

  if (command === "/meucastigo") {
    const active = punishments.get(senderNumber);
    return res.json({
      reply: active && active.until > Date.now()
        ? active.joke
        : "Você não tem castigo ativo 😇"
    });
  }

  if (command === "/pesquisa" || command === "/pesquisar") {
    return res.json({
      reply: args
        ? `🔎 Pesquisa solicitada: ${args}\nNesta versão inicial, a pesquisa online ainda não está conectada.`
        : "Use: /pesquisa assunto"
    });
  }

  if (command === "/play" || command === "/audio" || command === "/sticker") {
    return res.json({
      reply: "🧪 Comando recebido no protótipo. O envio real de áudio/figurinha precisa de uma integração de mídia."
    });
  }

  // Simula a regra de menções por pessoa. Só identifica o cadastro;
  // não baixa nem reenvia vídeos do TikTok.
  if (mentions.length) {
    const found = mentions
      .map((m) => normalizePerson(String(m)))
      .filter((person) => tiktokByPerson.has(person));

    if (found.length) {
      return res.json({
        reply: `🎬 Vídeo cadastrado encontrado para: ${found.map((p) => "@" + p).join(", ")}. Para enviar como vídeo, é necessário ter o arquivo e uma integração de envio de mídia compatível.`
      });
    }
  }

  return res.json({ reply: "Comando não reconhecido. Digite /menu." });
});

app.listen(PORT, () => {
  console.log(`Cunha Bot protótipo disponível na porta ${PORT}`);
});
